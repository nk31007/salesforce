import configparser
import os

class Settings:
    conf = configparser.RawConfigParser(strict=False)
    path = os.path.abspath(os.path.dirname(__file__))
    conf.read(os.path.join(path, 'netbackup.cfg'))
    #DATABASE
    DB_URI = conf.get('DATABASE', "DB_URI")
    SECRET_DB_KEY = conf.get('DATABASE', "SECRET_DB_KEY")
    # USER_NAME = conf.get('DATABASE', "USER_NAME")
    # PASSWORD = conf.get('DATABASE', "PASSWORD")
    # SERVER = conf.get('DATABASE', "SERVER")
    # PORT = conf.get('DATABASE', "PORT")
    # DB_NAME = conf.get('DATABASE', "DB_NAME")
    # DB_URI = f“postgresql://{USER_NAME}:{PASSWORD}@{SERVER}:{PORT}/{DATABASE}”
