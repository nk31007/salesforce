import connexion
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy


def create_app():


    connex_app = connexion.App(__name__, specification_dir="swagger/")
    connex_app.add_api("swagger.yml")
    flask_app = connex_app.app
    CORS(flask_app)
    import utils
    utils.init_app(flask_app)
    flask_app.run(host="0.0.0.0", port=8000, debug=True)

    # flask_app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
    # flask_app.config['SECRET_KEY'] = '3d6f45a5fc12445dbac2f59c3b6c7cb1'
    # app.add_api("swagger.yml")

    # @app.route("/")
    # def home():
    #     return render_template("home.html")

    # db = SQLAlchemy(flask_app)

    # db.init_app(app)
    # from datetime import datetime

    # with app.app_context():
    #     db.create_all()


if __name__ == "__main__":
    create_app()
    # flask_app.run(host="0.0.0.0", port=8000, debug=True)

