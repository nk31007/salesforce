# from models.contacts import DP_Contacts #, DP_Client, DP_Audit
from models.contacts import DP_Contacts 
# import json
from sqlalchemy import and_
from utils import db
import logging
logger = logging.getLogger("netbackup")
formatter = logging.Formatter('%(asctime)s:%(name)s:%(message)s')
file_handler = logging.FileHandler('storage.log')
file_handler.setFormatter(formatter)
file_handler.setLevel(logging.DEBUG)
stream_handler = logging.StreamHandler()
stream_handler.setFormatter(formatter)
stream_handler.setLevel(logging.DEBUG)
logger.addHandler(file_handler)
logger.addHandler(stream_handler)
logger.setLevel(logging.DEBUG)

def create_one(netbackup):
    """_summary_

    Args:
        netbackup (_type_): _description_

    Returns:
        _type_: _description_
    """

    clientname = netbackup.get("clientname")
    policy = netbackup.get("policy")
    sox_status = netbackup.get("sox_status")
    dp1 = DP_Contacts(clientname = clientname, policy=policy, sox_status=sox_status)
    db.session.add(dp1)
    db.session.commit()
    logger.info("Record has been added....")
    return f"The client {clientname} has been added to baackup policy {policy}"

def update(clientname, netbackup):
    """_summary_

    Args:
        clientname (_type_): _description_
        netbackup (_type_): _description_

    Returns:
        _type_: _description_
    """
    client_obj = DP_Contacts.query.filter_by(clientname=clientname).first()
    # db.session.query(DP_Contacts).filter(and_(DP_Contacts.clientname=clientname, DP_Contacts.policy=policy))
    new_backup_policy = netbackup.get('policy')
    client_obj.policy=new_backup_policy
    db.session.commit()
    return f"Backup Policy for the client {clientname} has been updated to {new_backup_policy}"

def delete_one(clientname, policy):
    """_summary_

    Args:
        clientname (_type_): _description_
        policy (_type_): _description_

    Returns:
        _type_: _description_
    """
    client_obj = db.session.query(DP_Contacts).filter(and_(DP_Contacts.clientname==clientname, DP_Contacts.policy==policy)).first()
    db.session.delete(client_obj)
    db.session.commit()
    return f"Backup Policy {policy} for the client {clientname} has been removed"

def read_one(clientname):
    """_summary_

    Args:
        clientname (_type_): _description_

    Returns:
        _type_: _description_
    """
    policies = db.session.query(DP_Contacts.policy).group_by(DP_Contacts.clientname).having(DP_Contacts.clientname==clientname).all()
    print(policies)
    # return policies.as_dict()