from utils.database_manager import DatabaseManager
from uuid import uuid4
from datetime import datetime

def generate_uuid():
    return str(uuid4())

def timetamp():
    return datetime.utcnow().timestamp()

database = DatabaseManager()
db = database.db

def init_app(app):
    database.init_app(app)