from flask_sqlalchemy import SQLAlchemy
from config import Settings

class DatabaseManager:
    """Manage Connexion with  Database
    """
    def __init__(self):
        self.db = SQLAlchemy()

    def  init_app(self, app):
         """Import data models and create tables into the database

         Arguments:
            app(Flask) -- Flask application to be configured
         """
         import models 
         models.load()
        #  print("database URI:"*10, Settings.DB_URI)
         app.config['SQLALCHEMY_DATABASE_URI']= Settings.DB_URI
         app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
         self.db.init_app(app)
         #  self.db.create_all()
         with app.app_context():
            self.db.create_all()

    def check_connection(self):
        try:
            with self.db.engine.connect() as connection:
                connection.execute("select 1;")
            return True
        except Exception:
            return False
