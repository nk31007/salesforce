# from sqlalchemy import Column, String, DateTime, JSON, Text, Integer
from datetime import datetime
from sqlalchemy.sql import func
from sqlalchemy.dialects.postgresql import UUID
from utils import db
from utils import generate_uuid, timetamp
from config import Settings

class DP_Contacts(db.Model):
    __tablename__ = "dp_contacts"
    _id = db.Column(db.String(50), primary_key=True, default = generate_uuid)
    clientname = db.Column(db.String(50),  nullable=False)
    policy =  db.Column(db.String(50),  nullable=False)
    date_created = db.Column(db.DateTime, nullable=False, default= datetime.utcnow)
    activity = db.Column(db.String(20))
    user = db.Column(db.String(20))
    team_name = db.Column(db.String(20))
    sox_status = db.Column(db.Boolean, nullable=False)
    
    def __init__(self, **kwargs) -> None:
        super(DP_Contacts, self).__init__(**kwargs)
    def as_dict(self):
       return {c.name: getattr(self, c.name) for c in self.__table__.columns}
    