def load():
    """Load data models  in order to allow datatables creation in  database
    """
    from models.contacts import DP_Contacts #, DP_Client, DP_Audit